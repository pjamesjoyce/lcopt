All rights reserved.

Redistribution and use in source and binary forms, with or without 
modification, are permitted provided that the following conditions are met:

Redistributions of source code must retain the above copyright notice, this 
list of conditions and the following disclaimer. Redistributions in binary 
form must reproduce the above copyright notice, this list of conditions and the 
following disclaimer in the documentation and/or other materials provided 
with the distribution.
The name of P. James Joyce nor the 
names of any contributors may be used to endorse or promote products derived 
from this software without specific prior written permission.
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE 
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE 
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER 
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
Description: # lcopt
        Life cycle optimisation module
        
        # Installation
        
        For lcopt to work you should have the latest version of [brightway2](https://brightwaylca.org/) by Chris Mutel installed.
        If you already have brightway installed, you can skip to the final step.
        
        The best option is to use conda to create a separate environment, to avoid conflicts.
        
        On the command line/console, create a new environment called lcopt
        
        ```
        conda create -y -n lcopt python=3.5 lxml cytoolz numpy scipy pandas
        ```
        
        Then activate the lcopt environment
        
        ```
        activate lcopt
        ```
        
        On windows there's an extra dependency
        ```
        conda install -y pywin32
        ```
        
        Then install brightway2 (and its dependecies)
        ```
        conda install wheel && conda update pip wheel setuptools
        conda install -q -y -c haasad pypardiso
        conda install -q -y ipython ipython-notebook jupyter matplotlib flask requests docopt whoosh xlsxwriter xlrd unidecode appdirs future psutil unicodecsv wrapt
        pip install --no-cache-dir eight brightway2
        ```
        
        Once brightway2 is ready fo go,  install lcopt via pip:
        
        ```
        pip install --no-cache-dir https://github.com/pjamesjoyce/lcopt/zipball/master
        ```
        
        Note - because lcopt is a work in progress currently, if you're reinstalling to get the latest version make sure you use the --no-cache-dir flag
        
        # Use
        
        The easiest way to use lcopt is via a jupyter notebook.
        
        `cd` into whatever folder you want your notebooks and lcopt models to be stored in, then start jupyter e.g.
        
        ```
        cd C:\Users\pjjoyce\Documents\01_Lcopt_models
        jupyter notebook
        ```
        
        This will fire up the jupyter notebook server in your browser.
        Create a new notebook, give it a meaningful name.
        
        Then in the first cell import lcopt
        ```python
        from lcopt import *
        ```
        
        Next create your LcoptModel
        ```python
        model = LcoptModel('MyFirstModel')
        ```
        
        Then launch the interactive model creator/analyser
        ```python
        model.launch_interact()
        ```
        This launches a Flask server that gives you a nice UI to interact with the models. You can add processes, link them together, add biosphere and technosphere exchanges, and create parameter sets and functions using your parameters. It should be pretty intuitive, if you get stuck, try the 'more info...' buttons.
        
        When your model's ready you can export it to SimaPro as a .csv file and the parameter sets you've created as an Excel file (Note: you need SimaPro developer to import the parameter sets from the Excel file).
        
        To run the analyses interactively using brightway2 there's an additional setup step. See below.
        
        The 'QUIT' button in the top right hand corner will shut down the Flask server and tell you to close the window.
        
        This frees up the notebook again so you can run any commands you need to. 
        
        One useful command is `model.save()` which will save any unsaved changes (you can also save by clicking on the save button in LcoptInteract, but in case you forget you can use `model.save()`)
        
        The model is saved as a .pickle file in your working directory.
        
        NOTE: The next time you run your notebook you need to change 
        ```python
        model = LcoptModel('MyFirstModel')
        ```
        to 
        ```python
        model = LcoptModel(load = 'MyFirstModel')
        ```
        
        If you don't it'll create a new blank model called 'MyFirstModel'. If you do do this by accident fear not - it won't overwrite your .pickle file until you save it. 
        Quit interact by hitting the QUIT button and go back and change your command (just don't click the save button or run `model.save()` in the meantime)
        
        
        ## Running the analyses in LcoptInteract with brightway2
        
        To use the interactive analysis feature, you need to set up brightway2 to play nicely with lcopt.
        Create a project in brightway called `setup_TO_COPY` which contains the biosphere3 database, the methods and the version of ecoinvent/any other external databases you want to use.
        The default name that lcopt looks for for ecoinvent is `Ecoinvent3_3_cutoff` (i.e. its database keys need to look like this `('Ecoinvent3_3_cutoff', '41f548bf636724eec735138986b33229')`).
        
        I'll try and add support for other versions asap.
        
        
Platform: UNKNOWN
Classifier: Intended Audience :: End Users/Desktop
Classifier: Intended Audience :: Developers
Classifier: Intended Audience :: Science/Research
Classifier: License :: OSI Approved :: BSD License
Classifier: Operating System :: MacOS :: MacOS X
Classifier: Operating System :: Microsoft :: Windows
Classifier: Operating System :: POSIX
Classifier: Programming Language :: Python
Classifier: Programming Language :: Python :: 3
Classifier: Programming Language :: Python :: 3.4
Classifier: Programming Language :: Python :: 3.5
Classifier: Topic :: Scientific/Engineering :: Information Analysis
Classifier: Topic :: Scientific/Engineering :: Mathematics
Classifier: Topic :: Scientific/Engineering :: Visualization
